from setuptools import setup, find_packages

setup(
    name='nvidia_monitor',
    version='0.1.1',
    description='NVIDIA GPU monitoring package written by KwangryeolPark',
    long_description=open('README.md', encoding='utf-8').read(),
    author='pkr7098',
    author_email='pkr7098@gmail.com',
    url='https://github.com/KwangryeolPark/PyPI.nvidia-monitor.git',
    install_requires=['tqdm'],
    packages=find_packages(exclude=[]),
    keywords=['nvidia-smi', 'gpu', 'monitor', 'nvidia', 'nvidia-monitor'],
    python_requires='>=3.7',
    package_data={},
    zip_safe=False,
    classifiers=[
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
    ],
)