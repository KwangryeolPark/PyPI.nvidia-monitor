from .queries import STATUS_QUERY 
from .queries import COMPUTE_QUERY
from .process import Process
from .status import Status

__version__ = '1.1.7'

