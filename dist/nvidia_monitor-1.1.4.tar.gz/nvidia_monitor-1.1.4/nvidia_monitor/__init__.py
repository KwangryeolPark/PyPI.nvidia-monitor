import nvidia_monitor.queries
import nvidia_monitor.gpu.process
import nvidia_monitor.gpu.status

__version__ = '1.1.4'

