import queries
import gpu.process
import gpu.status

__version__ = '1.1.2'

