from .queries import STATUS_QUERY 
from .queries import PROCESS_QUERY
from .process import Process
from .status import Status

__version__ = '1.1.5'

